from rest_framework.serializers import ModelSerializer
from places.models import Place, Gallery
from rest_framework import serializers



class PlacesSerializer(ModelSerializer):
	likes_count = serializers.IntegerField(source='likes.count', read_only=True)
	is_liked = serializers.SerializerMethodField()

	class Meta:
		model = Place
		fields = ("id", "name","featured_image", "place", "likes_count", "is_liked" )
	
	def get_is_liked(self, instance):
		request = self.context.get("request")
		user = request.user
		if user.is_authenticated:
			return instance.likes.filter(user=user).exists()
		return False



class GallerySerializer(ModelSerializer):
	class Meta:
		model = Gallery
		fields = ("id","image")

		

class PlacesDetailSerializer(ModelSerializer):

	likes_count = serializers.IntegerField(source='likes.count', read_only=True)
	is_liked = serializers.SerializerMethodField()

	category = serializers.SerializerMethodField()
	gallery = serializers.SerializerMethodField()

	class Meta:
		model = Place
		fields = ("id", "name","featured_image", "place","description", "category", "gallery" , "likes_count", "is_liked" )

	def get_is_liked(self, instance):
		request = self.context.get("request")
		user = request.user
		if user.is_authenticated:
			return instance.likes.filter(user=user).exists()
		return False

	def get_category(self, instance):
		return instance.category.name

	def get_gallery(self, instance):
		request = self.context.get("request")
		images = Gallery.objects.filter(place=instance)
		context={
		"request":request
		}
		serializer = GallerySerializer(images,many=True, context=context)
		return serializer.data