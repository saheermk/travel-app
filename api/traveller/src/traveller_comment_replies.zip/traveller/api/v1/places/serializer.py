from rest_framework.serializers import ModelSerializer
from places.models import Place, Gallery, Comment
from rest_framework import serializers



class PlacesSerializer(ModelSerializer):
	likes = serializers.SerializerMethodField()
	is_liked = serializers.SerializerMethodField()
	
	class Meta:
		model = Place
		fields = ("id", "name","featured_image", "place","likes", "is_liked")

	def get_likes(self, instance):
		return instance.likes.count()
	
	def get_is_liked(self, instance):
		request = self.context.get("request")
		if instance.likes.filter(username=request.user.username).exists():
			return True
		else:
			return False
		



class GallerySerializer(ModelSerializer):
	class Meta:
		model = Gallery
		fields = ("id","image")

		
class PlacesDetailSerializer(ModelSerializer):

	category = serializers.SerializerMethodField()
	gallery = serializers.SerializerMethodField()
	likes = serializers.SerializerMethodField()
	is_liked = serializers.SerializerMethodField()
	

	class Meta:
		model = Place
		fields = ("id", "name","featured_image", "place","description", "category", "gallery", "likes", "is_liked")

	def get_category(self, instance):
		return instance.category.name

	def get_gallery(self, instance):
		request = self.context.get("request")
		images = Gallery.objects.filter(place=instance)
		context={
		"request":request
		}
		serializer = GallerySerializer(images,many=True, context=context)
		return serializer.data
	
	def get_likes(self, instance):
		return instance.likes.count()
	
	def get_is_liked(self, instance):
		request = self.context.get("request")
		if instance.likes.filter(username=request.user.username).exists():
			return True
		else:
			return False
		
	


class CommentSerializer(ModelSerializer):

	user = serializers.SerializerMethodField()
	date = serializers.SerializerMethodField()
	replies = serializers.SerializerMethodField()	


	class Meta:
		model = Comment
		fields = ("id","comment","user","date", "replies")

	def get_user(self, instance):
		return instance.user.first_name
	
	def get_date(self, instance):
		return instance.date.strftime("%d %B %Y")
	def get_replies(self, instance):
		request = self.context.get("request")
		replies = Comment.objects.filter(parent=instance)
		context={
		"request":request
		}
		serializer = CommentSerializer(replies,many=True, context=context)
		return serializer.data