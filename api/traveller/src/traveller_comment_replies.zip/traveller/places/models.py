from django.db import models


class Place(models.Model):
	name = models.CharField(max_length=255)
	featured_image = models.FileField(upload_to="places/images/")
	place = models.CharField(max_length=255)
	category = models.ForeignKey("places.Category", on_delete=models.CASCADE)
	description = models.TextField()
	is_deleted = models.BooleanField(default=False)
	likes = models.ManyToManyField("auth.User", blank=True, related_name="place_likes")

	class Meta():
		db_table = "place_place"

	def __str__(self):
		return self.name
	

class Category(models.Model):
	image = models.FileField(upload_to=("categories/images/"))
	name = models.CharField(max_length=255)
	
	class Meta():
		db_table = "place_category"
		verbose_name_plural = "Categories"

	def __str__(self):
		return self.name
	


class Gallery(models.Model):
	place = models.ForeignKey("places.Place", on_delete=models.CASCADE)
	image = models.FileField(upload_to=("places/images/"))

	class Meta():
		db_table = "place_gallery"
		verbose_name_plural = "Gallery"

	def __str__(self):
		return str(self.id)
	

class Comment(models.Model):
	place = models.ForeignKey("places.Place", on_delete=models.CASCADE)
	user = models.ForeignKey("auth.User", on_delete=models.CASCADE)
	date = models.DateTimeField()
	comment = models.TextField()
	parent = models.ForeignKey("places.Comment", on_delete=models.CASCADE, null=True, blank=True, related_name="replies")

	class Meta():
		db_table = "place_comment"
		verbose_name_plural = "Comments"

	def __str__(self):
		return f"Comment by {self.user} on {self.place}"
