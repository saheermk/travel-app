from django.db import models
from django.contrib.auth.models import User


class Place(models.Model):
	name = models.CharField(max_length=255)
	featured_image = models.FileField(upload_to="places/images/")
	place = models.CharField(max_length=255)
	category = models.ForeignKey("places.Category", on_delete=models.CASCADE)
	description = models.TextField()
	is_deleted = models.BooleanField(default=False)

	class Meta():
		db_table = "place_place"

	def __str__(self):
		return self.name
	

class Category(models.Model):
	image = models.FileField(upload_to=("categories/images/"))
	name = models.CharField(max_length=255)
	
	class Meta():
		db_table = "place_category"
		verbose_name_plural = "Categories"

	def __str__(self):
		return self.name
	


class Gallery(models.Model):
	place = models.ForeignKey("places.Place", on_delete=models.CASCADE)
	image = models.FileField(upload_to=("places/images/"))

	class Meta():
		db_table = "place_gallery"
		verbose_name_plural = "Gallery"

	def __str__(self):
		return str(self.id)
	


class Like(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	place = models.ForeignKey(Place, on_delete=models.CASCADE, related_name='likes')
	created_at = models.DateTimeField(auto_now_add=True)
	
	class Meta:
		db_table = "place_like"
		unique_together = ('user', 'place')

	def __str__(self):
		return f"{self.user.username} likes {self.place.name}"
	


class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    place = models.ForeignKey('Place', on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']  

    def __str__(self):
        return f"{self.user.username} commented on {self.place.name}"