from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny

from api.v1.places.serializer import CommentSerializer
from api.v1.places.serializer import PlacesSerializer, PlacesDetailSerializer
from places.models import Place, Comment
from django.db.models import Q
from api.v1.places.pagination import StandardResultSetPagination

from places.models import Place, Like


@api_view(["GET"])
@permission_classes([AllowAny])
def places(request):
	instances = Place.objects.filter(is_deleted = False)

	q = request.GET.get("q")
	if q:
		ids = q.split(",")
		instances = instances.filter(Q(name__icontains=q) |
							    Q(description__icontains=q) |
								  Q(category__name__icontains=q ) |
								    Q(description__icontains=q ) |
									  Q(category__in=ids ),
										  )

	paginator = StandardResultSetPagination()
	paginator_result = paginator.paginate_queryset(instances, request)

	context={
		"request":request
	}
	serializer = PlacesSerializer(paginator_result, many=True, context=context)
	response_data = {
		"status_code" : 6000,
		"count" : paginator.page.paginator.count,
		"links":{
			"next" : paginator.get_next_link() ,
			"previous":  paginator.get_previous_link() 
		},
		"data" : serializer.data,
		
	}

	return Response(response_data)


@api_view(["GET"])
@permission_classes([AllowAny])
def place(request,pk):
	if Place.objects.filter(pk=pk).exists():
		instances = Place.objects.get(pk=pk)
		context={
			"request":request
		}
		serializer = PlacesDetailSerializer(instances, context=context)
		response_data = {
			"status_code" : 6000,
			"data" : serializer.data,
			
		}

		return Response(response_data)

	else:
		response_data = {
			"status_code" : 6001,
			"message" : "place not exists",
			
		}
		return Response(response_data)




@api_view(["GET"])
@permission_classes([IsAuthenticated])
def protected(request,pk):
	if Place.objects.filter(pk=pk).exists():
		instances = Place.objects.get(pk=pk)
		context={
			"request":request
		}
		serializer = PlacesDetailSerializer(instances, context=context)
		response_data = {
			"status_code" : 6000,
			"data" : serializer.data,
			
		}

		return Response(response_data)

	else:
		response_data = {
			"status_code" : 6001,
			"message" : "place not exists",
			
		}
		return Response(response_data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def like(request, pk):

    if not Place.objects.filter(pk=pk, is_deleted=False).exists():
        return Response({
            "status_code": 6001,
            "message": "Place not exists"
        })

    place = Place.objects.get(pk=pk)

    like_qs = Like.objects.filter(user=request.user, place=place)

    if like_qs.exists():
        like_qs.delete()
        message = "Place unliked"
    else:
        Like.objects.create(user=request.user, place=place)
        message = "Place liked"

    serializer = PlacesDetailSerializer(place, context={"request": request})

    return Response({
        "status_code": 6000,
        "message": message,
        "data": serializer.data
    })



@api_view(["POST"])
@permission_classes([IsAuthenticated])
def post_comment(request, pk):
    if not Place.objects.filter(pk=pk, is_deleted=False).exists():
        return Response({
			"status_code": 6001, 
			"message": "Place not exists"
			})

    place = Place.objects.get(pk=pk)
    text = request.data.get('text')

    if not text:
        return Response({"status_code": 6002, "message": "Comment text is required"})

    comment = Comment.objects.create(user=request.user, place=place, text=text)

    serializer = CommentSerializer(comment)

    return Response({
        "status_code": 6000,
        "message": "Comment posted",
        "data": serializer.data
    })

@api_view(["GET"])
def list_comments(request, pk):
    
    if not Place.objects.filter(pk=pk, is_deleted=False).exists():
        return Response({"status_code": 6001, "message": "Place not exists"})

    place = Place.objects.get(pk=pk)
    comments = place.comments.all() 

    serializer = CommentSerializer(comments, many=True)

    return Response({
        "status_code": 6000,
        "count": comments.count(),
        "data": serializer.data
    })
