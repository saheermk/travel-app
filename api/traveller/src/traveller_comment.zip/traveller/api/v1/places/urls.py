from django.urls import path
from api.v1.places import views

urlpatterns = [
    path('', views.places),
    path('view/<int:pk>', views.place),
    path('protected/<int:pk>', views.protected),
    path('place/<int:pk>/like/', views.like, name='like'),
    path('place/<int:pk>/comment/', views.post_comment, name='post-comment'),
    path('place/<int:pk>/comments/', views.list_comments, name='list-comments'),
]
